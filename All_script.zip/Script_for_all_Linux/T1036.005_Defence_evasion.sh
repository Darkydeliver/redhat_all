#!/bin/bash

# Ensure the output directory exists
output_dir="./Linux_output/Defence_Evasion"
mkdir -p "$output_dir"

# Output file
output_file="$output_dir/T1036.005_Defence_evasion.txt"

# Input parameters
test_message="Hello from the SISA test T1036.005#1"

# Create the masquerading directory in the user's home
masquerade_dir="$HOME/..."
mkdir -p "$masquerade_dir"

# Check if 'sh' executable exists
sh_path="$(which sh)"
if [ -z "$sh_path" ]; then
    echo "'sh' shell not found on this system." | tee -a "$output_file"
    exit 1
fi

# Copy the system shell executable (sh) to the masquerading directory
cp "$sh_path" "$masquerade_dir"

# Verify that the copied shell is present in the masquerading directory
if [ ! -f "$masquerade_dir/sh" ]; then
    echo "Failed to copy 'sh' to $masquerade_dir." | tee -a "$output_file"
    exit 1
fi

# Execute a command using the copied shell from the masquerading directory
echo "Executing command using the copied shell:" | tee -a "$output_file"
"$masquerade_dir/sh" -c "echo $test_message" | tee -a "$output_file"

# Cleanup: Remove the copied shell and the masquerading directory
rm -f "$masquerade_dir/sh"
rmdir "$masquerade_dir"

# Print completion message
echo "Execution completed. Output saved to $output_file" | tee -a "$output_file"

