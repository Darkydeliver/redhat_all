import openpyxl

# Load the NEPS - BAS.xlsx file and Discovery.txt
neps_workbook = openpyxl.load_workbook('NEPS - BAS.xlsx')
neps_sheet = neps_workbook.active

# Create the report.xlsx file
report_workbook = openpyxl.Workbook()
report_sheet = report_workbook.active

# Add headers to report.xlsx
report_sheet['A1'] = 'Tactic Name'
report_sheet['B1'] = 'Logs and Alarm Triggered'

# Open the Discovery.txt file and read commands line by line
with open('Discovery.txt', 'r') as discovery_file:
    commands = discovery_file.readlines()

# Iterate through each command in Discovery.txt
row_num = 2
for command in commands:
    command = command.strip()  # Clean up command (remove newlines, spaces)

    # Iterate over rows in NEPS - BAS.xlsx to find matching commands
    for row in neps_sheet.iter_rows(values_only=True):
        if command in row:  # Check if command matches any cell in the row
            # Copy the entire row from NEPS - BAS.xlsx into report.xlsx
            tactic_name = row[0]  # Assuming the first column in NEPS is the Tactic Name
            logs_and_alarms = " ".join(str(cell) for cell in row[1:])  # Combine the rest as Logs & Alarm
            
            # Write matched data into report.xlsx
            report_sheet[f'A{row_num}'] = tactic_name
            report_sheet[f'B{row_num}'] = logs_and_alarms
            row_num += 1

# Save the report.xlsx file
report_workbook.save('report.xlsx')

print("Report generation completed and saved as 'report.xlsx'")
