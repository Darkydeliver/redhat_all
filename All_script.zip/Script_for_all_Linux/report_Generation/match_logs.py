import pandas as pd
import re
from datetime import datetime

# Load the Excel file
file_path = 'NEPS - BAS.xlsx'
df = pd.read_excel(file_path)

# Display the columns in the loaded Excel file
print("Columns in the loaded Excel file:")
print(df.columns)

# Get the log column dynamically
log_column = df.columns[df.columns.str.contains('message', case=False)].tolist()
if not log_column:
    raise ValueError("No suitable log column found.")
log_column = log_column[0]  # Get the first match

# Load the commands to search for (the full Linux command structure with arguments)
commands = [
    'a0="who"',
    'a0="w"',
    'a0="users"',
    'a0="cat"',
    'a0="sudo"',
    'a0="grep"',
    'a0="uname"',
    'a0="groups"',
    'a0="systemd-detect-virt"',
    'a0="systemctl"',
    'a0="smbstatus"',
    'a0="uptime"',
    'a0="hostname"',
    'a0="env"',
    'a0="find"',
    'a0="arp"',
    'a0="ifconfig"',
    'a0="netstat"',
    'a0="ls"',
    'a0="sed"',
    'a0="ps"',
    'a0="getent"',
    'a0="id"',
    'a0="locale"',
    'a0="ip"'
]

# Function to search for Linux commands in logs
def find_commands(log, commands):
    if isinstance(log, str):  # Ensure log is a string
        log = log.lower().strip()  # Ensure log is lowercase and stripped of extra spaces
        print(f"Processing log: {log}")  # Debug: Print the log being processed
        for command in commands:
            # Search for the exact match of the command (e.g., a0="who")
            if re.search(r'\b{}\b'.format(re.escape(command)), log):
                print(f"Command found: {command} in log: {log}")  # Debug: Print when a command is found
                return True
    return False

# Function to extract time from a log message using regex
def extract_time(log):
    time_pattern = r'\b(\d{2}:\d{2}:\d{2})\b'  # Matches HH:MM:SS format
    match = re.search(time_pattern, log)
    if match:
        return match.group(0)  # Return the first matched time string
    return None

# Filter the DataFrame to only include rows where 'message' or 'alarm_name' is not empty
filtered_df = df[(df['message'].notna()) | (df['alarm_name'].notna())]

# Apply the function to search for commands in the log column
filtered_df['Contains Command'] = filtered_df[log_column].apply(lambda log: find_commands(log, commands))

# Check how many rows were processed
print(f"Total logs processed: {len(filtered_df)}")

# Filter rows where a command was found
matching_logs = filtered_df[filtered_df['Contains Command']]

# If no matching logs, print a message
if matching_logs.empty:
    print("No matching logs found.")
else:
    # Extract time from each log message
    matching_logs['Extracted Time'] = matching_logs[log_column].apply(extract_time)

    # Remove rows where no time could be extracted
    matching_logs = matching_logs[matching_logs['Extracted Time'].notna()]

    # Convert extracted time to datetime object for comparison
    matching_logs['Extracted Time'] = matching_logs['Extracted Time'].apply(lambda x: datetime.strptime(x, '%H:%M:%S'))

    # Remove duplicates and keep the most recent log based on the extracted time
    matching_logs = matching_logs.sort_values('Extracted Time').drop_duplicates(subset=log_column, keep='last')

    # Add the 'Tactic Name' column and set its value to 'Discovery'
    matching_logs['Tactic Name'] = 'Discovery'

    # Reorder columns to have 'Tactic Name' as the first column
    matching_logs = matching_logs[['Tactic Name'] + [col for col in matching_logs.columns if col != 'Tactic Name']]

    # Output the result to a new Excel file
    output_path = 'matching_logs.xlsx'
    matching_logs.to_excel(output_path, index=False)
    print(f"Found {len(matching_logs)} matching logs. Results saved to {output_path}.")
