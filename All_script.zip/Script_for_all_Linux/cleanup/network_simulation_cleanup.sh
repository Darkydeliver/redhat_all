#!/bin/bash

# Set the base output directory and subdirectory
BASE_OUTPUT_DIR="./Linux_output"
SUB_DIR="Network_Simulation_Alt"
OUTPUT_FILE="Network_Simulation_Alt_output.txt"

# Create the base output directory if it doesn't exist
if [ ! -d "$BASE_OUTPUT_DIR" ]; then
    mkdir -p "$BASE_OUTPUT_DIR"
fi

# Create the subdirectory if it doesn't exist
if [ ! -d "$BASE_OUTPUT_DIR/$SUB_DIR" ]; then
    mkdir -p "$BASE_OUTPUT_DIR/$SUB_DIR"
fi

# Set the full path to the output file
OUTPUT_PATH="$BASE_OUTPUT_DIR/$SUB_DIR/$OUTPUT_FILE"

# Function to log output
log_output() {
    local message="$1"
    echo "$message" | tee -a "$OUTPUT_PATH"
}

# Example command to install a tool (e.g., nmap) and log the output
log_output "Installing nmap..."
if ! command -v nmap &> /dev/null; then
    apt-get update && apt-get install -y nmap 2>&1 | tee -a "$OUTPUT_PATH"
    if [ $? -eq 0 ]; then
        log_output "nmap installed successfully."
    else
        log_output "Error: Failed to install nmap."
        exit 1
    fi
else
    log_output "nmap is already installed."
fi

# Example commands to run nmap and log the output
log_output "Running nmap commands..."
log_output "Scanning localhost with nmap..."
nmap 127.0.0.1 2>&1 | tee -a "$OUTPUT_PATH"

log_output "Scanning top 1000 ports on localhost..."
nmap -F 127.0.0.1 2>&1 | tee -a "$OUTPUT_PATH"

log_output "Running OS detection scan on localhost..."
nmap -O 127.0.0.1 2>&1 | tee -a "$OUTPUT_PATH"

log_output "Running SYN scan on localhost..."
nmap -sS 127.0.0.1 2>&1 | tee -a "$OUTPUT_PATH"

# Additional network simulation with hping3 (example of port scanning)
log_output "Installing hping3..."
if ! command -v hping3 &> /dev/null; then
    apt-get install -y hping3 2>&1 | tee -a "$OUTPUT_PATH"
    if [ $? -eq 0 ]; then
        log_output "hping3 installed successfully."
    else
        log_output "Error: Failed to install hping3."
        exit 1
    fi
else
    log_output "hping3 is already installed."
fi

log_output "Running hping3 TCP SYN flood simulation..."
hping3 -S -p 80 -c 1000 127.0.0.1 2>&1 | tee -a "$OUTPUT_PATH"

log_output "Running hping3 ICMP flood simulation..."
hping3 -1 -c 1000 127.0.0.1 2>&1 | tee -a "$OUTPUT_PATH"

log_output "Running hping3 UDP scan on localhost..."
hping3 --udp -p 80 -c 1000 127.0.0.1 2>&1 | tee -a "$OUTPUT_PATH"

log_output "All commands executed. Output saved to $OUTPUT_PATH."
