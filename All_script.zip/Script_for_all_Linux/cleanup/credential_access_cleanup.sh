#!/bin/bash

# Define the common cleanup log directory
cleanup_log_dir="Linux_output/Credential_access"
mkdir -p "$cleanup_log_dir"

# Define individual cleanup log files
cleanup_log_file="${cleanup_log_dir}/cleanup_Credential_access.txt"
cleanup_log_file_1040="${cleanup_log_dir}/cleanup_T1040_Credential_access.txt"
cleanup_log_file_007="${cleanup_log_dir}/cleanup_T1003.007_Credential_access.txt"
cleanup_log_file_008="${cleanup_log_dir}/cleanup_T1003.008_Credential_access.txt"

# Function to log cleanup actions
log_cleanup() {
    local message="$1"
    local log_file="$2"
    echo "$message" | tee -a "$log_file"
}

# Function to remove a user
remove_user() {
    local user="$1"
    if id "$user" &>/dev/null; then
        log_cleanup "Removing user '$user'..." "$cleanup_log_file"
        sudo deluser "$user" --remove-home
        log_cleanup "User '$user' removed." "$cleanup_log_file"
    else
        log_cleanup "User '$user' does not exist." "$cleanup_log_file"
    fi
}

# Cleanup actions

# 1. Remove test users
log_cleanup "Removing test users 'testuser' and 'art'..." "$cleanup_log_file"
remove_user "testuser"
remove_user "art"

# 2. Restore PAM configuration files
log_cleanup "Restoring PAM configuration files..." "$cleanup_log_file"
if [ -f "/tmp/system-auth.bak" ]; then
    sudo mv /tmp/system-auth.bak /etc/pam.d/system-auth
    log_cleanup "Restored /etc/pam.d/system-auth." "$cleanup_log_file"
fi
if [ -f "/tmp/sshd.bak" ]; then
    sudo mv /tmp/sshd.bak /etc/pam.d/sshd
    log_cleanup "Restored /etc/pam.d/sshd." "$cleanup_log_file"
fi

# 3. Remove temporary files
log_cleanup "Cleaning up temporary files..." "$cleanup_log_file"
rm -f /tmp/.keyboard.log
rm -f /tmp/linux_pcapdemo.c
rm -f /tmp/linux_pcapdemo

# Cleanup actions for T1040 Credential Access
log_cleanup "Starting cleanup for T1040 Credential Access network capture script..." "$cleanup_log_file_1040"
output_file_1040="${cleanup_log_dir}/T1040_Credential_access.txt"
if [ -f "$output_file_1040" ]; then
    log_cleanup "Output file found: $output_file_1040. Reviewing cleanup options..." "$cleanup_log_file_1040"
    log_cleanup "Note: The output file contains results of packet captures for review. Consider archiving it if required for audit purposes." "$cleanup_log_file_1040"
    # Uncomment the line below if you decide to remove the output file
    # rm -f "$output_file_1040" && log_cleanup "Removed output file: $output_file_1040." "$cleanup_log_file_1040"
else
    log_cleanup "No output file found at $output_file_1040. Nothing to clean." "$cleanup_log_file_1040"
fi
log_cleanup "Cleanup completed for T1040 Credential Access script." "$cleanup_log_file_1040"

# Cleanup actions for T1003.007 Credential Access
log_cleanup "Starting cleanup for T1003.007 Credential Access script..." "$cleanup_log_file_007"
output_file_007="/tmp/T1003.007.bin"
if [ -f "$output_file_007" ]; then
    log_cleanup "Removing the memory dump file: $output_file_007..." "$cleanup_log_file_007"
    rm -f "$output_file_007"
    if [ $? -eq 0 ]; then
        log_cleanup "Memory dump file removed successfully." "$cleanup_log_file_007"
    else
        log_cleanup "Failed to remove the memory dump file." "$cleanup_log_file_007"
    fi
else
    log_cleanup "Memory dump file $output_file_007 does not exist. No action needed." "$cleanup_log_file_007"
fi
log_cleanup "Cleanup completed for T1003.007 Credential Access script." "$cleanup_log_file_007"

# Cleanup actions for T1003.008 Credential Access
log_cleanup "Starting cleanup for T1003.008 Credential Access script..." "$cleanup_log_file_008"
output_file_008="${cleanup_log_dir}/T1003.008_Credential_access.txt"
if [ -f "$output_file_008" ]; then
    log_cleanup "Output file found: $output_file_008. Reviewing cleanup options..." "$cleanup_log_file_008"
    log_cleanup "Note: The output file contains command results for review. Consider archiving it if required for audit purposes." "$cleanup_log_file_008"
    # Uncomment the line below if you decide to remove the output file
    # rm -f "$output_file_008" && log_cleanup "Removed output file: $output_file_008." "$cleanup_log_file_008"
else
    log_cleanup "No output file found at $output_file_008. Nothing to clean." "$cleanup_log_file_008"
fi
log_cleanup "Cleanup completed for T1003.008 Credential Access script." "$cleanup_log_file_008"

# 4. Remove combined output logs if necessary
log_cleanup "Removing additional output logs..." "$cleanup_log_file"
rm -f "${cleanup_log_dir}/T1040_Credential_access.txt"
rm -f "${cleanup_log_dir}/T1003.007_Credential_access.txt"
rm -f "${cleanup_log_dir}/T1003.008_Credential_access.txt"
rm -f "${cleanup_log_dir}/T1056.001_Credential_access.txt"
rm -f "${cleanup_log_dir}/T1110.001_Credential_access.txt"

# Final message
log_cleanup "Combined cleanup completed for all Credential Access scripts. All actions logged in respective cleanup log files." "$cleanup_log_file"

